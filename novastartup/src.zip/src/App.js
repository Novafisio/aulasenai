import Menu from './Componentes/menu';
import Rodape from './Componentes/rodape';
import Background from './Componentes/background'
import Home from './Paginas/home';
import Sobre from './Paginas/sobre';
import Cadastro from './Paginas/cadastro';
import Login from './Paginas/login';
import {BrowserRouter,Route,Routes} from "react-router-dom";

function App() {
  return (
    <>

    
    <BrowserRouter>
    <Routes>
      
      <Route path='/' element={<Home/>}/>
      <Route path='Sobre' element={<Sobre/>}/>
      <Route path= 'Cadastro' element={<Cadastro/>}/>
      <Route path='Login' element={<Login/>}/>

    </Routes>
    </BrowserRouter>


    </>
  );
}

export default App;
