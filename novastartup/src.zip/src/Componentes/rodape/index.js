export default function Rodape() {
  return (
    <div className="container">
      <footer className="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">

        <div className="col-md-4 d-flex align-items-center">
          <a
            href="/"
            className="mb-3 me-2 mb-md-0 text-body-secondary text-decoration-none lh-1"
          >
          </a>
        </div>

        <span className="mb-3 mb-md-0 text-body-secondary w-100 text-center d-block">
          © 2026 NOVA, Startup
        </span>

        <ul className="nav col-md-4 justify-content-end list-unstyled d-flex">
          <li className="ms-3">
            <a className="text-body-secondary" aria-label="Instagram"></a>
          </li>
        </ul>

      </footer>
    </div>
  );
}