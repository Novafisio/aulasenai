import Menu from "../../Componentes/menu";
import Rodape from "../../Componentes/rodape";
import login from "../../Componentes/imagens/login.png"

export default function Login(){
    return(
        <>
        <Menu></Menu>
        <img src={login} style={{
            height:500,
            width:1000
            
        }}/>
        <Rodape></Rodape>
        
        </>
    )
}