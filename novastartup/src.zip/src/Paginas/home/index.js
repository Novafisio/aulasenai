import Menu from '../../Componentes/menu';
import Background from '../../Componentes/background';
import Rodape from '../../Componentes/rodape';

export default function Home() {
  return (
    <>
      <Menu/>
      <Background/>
      <Rodape/>
    </>
  );
}
