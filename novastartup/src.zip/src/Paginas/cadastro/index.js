import Background from "../../Componentes/background";
import Formulario from "../../Componentes/formulario";
import Menu from "../../Componentes/menu";
import Rodape from "../../Componentes/rodape";

export default function Cadastro(){
    return(
        <>
        <Menu></Menu>
        <Formulario></Formulario>
        <Rodape></Rodape>
        </>
    )
}